// let FetchLink = async () => {
//     fetch("http://127.0.0.1:7000/log/getlink")
//       .then((response) => response.json())
//       .then((data) => setLink(data.filename));
//   };